using System;
using System.Diagnostics;
using System.Threading;

namespace ProcessTarget
{
    internal class Program
    {
        private static int Main()
        {
            Console.Title = "EDR Process Target";
            Console.WriteLine("[TARGET-READY] Process=ProcessTarget.exe");
            Console.WriteLine("[TARGET-READY] PID=" + Process.GetCurrentProcess().Id);
            Console.WriteLine("[TARGET-READY] StartUTC=" + DateTime.UtcNow.ToString("yyyy-MM-dd'T'HH:mm:ss.fff'Z'"));
            Console.WriteLine("[TARGET-READY] LifetimeMinutes=30");
            Thread.Sleep(TimeSpan.FromMinutes(30));
            return 0;
        }
    }
}
