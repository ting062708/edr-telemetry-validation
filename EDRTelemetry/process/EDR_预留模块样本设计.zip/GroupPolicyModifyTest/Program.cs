using System;
using System.Diagnostics;
using System.Threading;
using Microsoft.Win32;

namespace GroupPolicyModifyTest
{
    internal class Program
    {
        private static readonly string RunId = Guid.NewGuid().ToString("N");
        private static readonly int Pid = Process.GetCurrentProcess().Id;
        private static readonly string Host = Environment.MachineName;

        // 组策略存储的注册表路径（HKLM\...\Policies 下，触发 IOA 组策略修改检测）
        private const string PolicyKey = @"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System";
        private const string PolicyValueName = "EDRTelemetryGpoTest";
        private const string PolicyValueData = "1";

        private static int Main(string[] args)
        {
            PrintRunBegin();
            int exitCode = 0;

            try
            {
                if (!IsAdministrator())
                {
                    Console.WriteLine("[ERROR] Administrator privileges required to modify HKLM Group Policy.");
                    exitCode = 1;
                }
                else
                {
                    // ── SETUP：检查目标键，记录初始值 ─────────────────
                    PrintSetupBegin();
                    PrintSetup("RegKeyPath", @"HKLM\" + PolicyKey);
                    PrintSetup("RegValueName", PolicyValueName);
                    int? oldValue = ReadPolicyValue();
                    PrintSetup("PreExistingValue", oldValue.HasValue ? oldValue.Value.ToString() : "(none)");
                    PrintSetupEnd();

                    Thread.Sleep(3000); // 隔离 SETUP / TARGET 窗口

                    // ── TARGET：写入组策略值（RegSetValue）──────────
                    PrintTargetBegin();
                    WritePolicyValue(PolicyValueData);
                    PrintTarget("Operation", "RegSetValue");
                    PrintTarget("RegKeyPath", @"HKLM\" + PolicyKey);
                    PrintTarget("RegValueName", PolicyValueName);
                    PrintTarget("RegValueData", PolicyValueData);
                    PrintTargetEnd();

                    // 校验写入成功
                    int? after = ReadPolicyValue();
                    if (after == null || after.Value.ToString() != PolicyValueData)
                    {
                        Console.WriteLine("[ERROR] Failed to verify registry value after write.");
                        exitCode = 1;
                    }
                    else
                    {
                        RestorePolicyValue(oldValue); // cleanup，在 TARGET 窗口外
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("[ERROR] " + ex.GetType().Name + ": " + ex.Message);
                exitCode = 1;
            }
            finally
            {
                Console.WriteLine("[RESULT] " + (exitCode == 0 ? "PASS ExitCode=0" : "FAIL ExitCode=1"));
                PrintRunEnd();
            }

            return exitCode;
        }

        private static int? ReadPolicyValue()
        {
            using (RegistryKey key = Registry.LocalMachine.OpenSubKey(PolicyKey, false))
            {
                if (key == null) return null;
                object v = key.GetValue(PolicyValueName);
                return v == null ? (int?)null : Convert.ToInt32(v);
            }
        }

        private static void WritePolicyValue(string data)
        {
            using (RegistryKey key = Registry.LocalMachine.CreateSubKey(PolicyKey))
            {
                key.SetValue(PolicyValueName, data, RegistryValueKind.DWord);
            }
        }

        private static void RestorePolicyValue(int? oldValue)
        {
            try
            {
                using (RegistryKey key = Registry.LocalMachine.OpenSubKey(PolicyKey, true))
                {
                    if (key == null) return;
                    if (oldValue.HasValue)
                        key.SetValue(PolicyValueName, oldValue.Value, RegistryValueKind.DWord);
                    else
                        key.DeleteValue(PolicyValueName, false);
                }
            }
            catch { }
        }

        private static bool IsAdministrator()
        {
            using (var identity = System.Security.Principal.WindowsIdentity.GetCurrent())
            {
                var principal = new System.Security.Principal.WindowsPrincipal(identity);
                return principal.IsInRole(System.Security.Principal.WindowsBuiltInRole.Administrator);
            }
        }

        // ── 协议输出 ────────────────────────────────────────────────
        private static void PrintRunBegin()
        {
            Console.WriteLine("[RUN-BEGIN] RunID=" + RunId + " TimeUTC=" + UtcNow());
            Console.WriteLine("[META] TestCaseID=GPO-MODIFY-001");
            Console.WriteLine("[META] Module=GPO");
            Console.WriteLine("[META] Action=gpo_modify");
            Console.WriteLine("[META] Process=GroupPolicyModifyTest.exe");
            Console.WriteLine("[META] PID=" + Pid);
            Console.WriteLine("[META] Hostname=" + Host);
            Console.WriteLine("[META] RunStartUTC=" + UtcNow());
        }

        private static void PrintSetupBegin() { Console.WriteLine("[SETUP-BEGIN] TimeUTC=" + UtcNow()); }
        private static void PrintSetupEnd() { Console.WriteLine("[SETUP-END] TimeUTC=" + UtcNow()); }
        private static void PrintSetup(string k, string v) { Console.WriteLine("[SETUP] " + k + "=" + v); }
        private static void PrintTargetBegin() { Console.WriteLine("[TARGET-BEGIN] TimeUTC=" + UtcNow()); }
        private static void PrintTargetEnd() { Console.WriteLine("[TARGET-END] TimeUTC=" + UtcNow()); }
        private static void PrintTarget(string k, string v) { Console.WriteLine("[TARGET] " + k + "=" + v); }
        private static void PrintRunEnd() { Console.WriteLine("[RUN-END] RunID=" + RunId + " TimeUTC=" + UtcNow()); }

        private static string UtcNow()
        {
            return DateTime.UtcNow.ToString("yyyy-MM-dd'T'HH:mm:ss.fff'Z'");
        }
    }
}
