using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;

namespace ScheduledTaskLifecycleTest
{
    internal class Program
    {
        private const string TaskName = "EDR_Telemetry_Test_Task";
        private const int TASK_TRIGGER_TIME = 1;
        private const int TASK_ACTION_EXEC = 0;
        private const int TASK_CREATE = 0x2;
        private const int TASK_UPDATE = 0x4;
        private const int TASK_LOGON_INTERACTIVE_TOKEN = 3;

        private static int Main(string[] args)
        {
            string caseId;
            if (!TryGetCase(args, out caseId))
            {
                Console.WriteLine("[ERROR] Usage: ScheduledTaskLifecycleTest.exe --case TASK-CREATE-001|TASK-MODIFY-001|TASK-DELETE-001");
                return 2;
            }

            string action = GetAction(caseId);
            if (action == null)
            {
                Console.WriteLine("[ERROR] Unknown TestCaseID=" + caseId);
                return 2;
            }

            string runId = Guid.NewGuid().ToString("N");
            RunBegin(runId);
            Console.WriteLine("[META] TestCaseID=" + caseId + " Module=ScheduledTask Action=" + action);
            Console.WriteLine("[META] Process=ScheduledTaskLifecycleTest.exe PID=" + Process.GetCurrentProcess().Id + " Hostname=" + Environment.MachineName);

            try
            {
                switch (caseId)
                {
                    case "TASK-CREATE-001": RunCreate(); break;
                    case "TASK-MODIFY-001": RunModify(); break;
                    case "TASK-DELETE-001": RunDelete(); break;
                }

                Console.WriteLine("[RESULT] PASS ExitCode=0");
                return 0;
            }
            catch (Exception ex)
            {
                Console.WriteLine("[ERROR] " + Sanitize(FormatException(ex)));
                Console.WriteLine("[RESULT] FAIL ExitCode=1");
                return 1;
            }
            finally
            {
                RunEnd(runId);
            }
        }

        private static void RunCreate()
        {
            dynamic service = null, root = null, definition = null, trigger = null, action = null, registered = null;
            try
            {
                SetupBegin();
                OpenScheduler(out service, out root);
                DeleteTaskIfPresent(root);
                DateTime triggerTime = DateTime.Now.AddHours(24);
                definition = BuildDefinition(service, "EDR Scheduled Task Creation Test", triggerTime, out trigger, out action);
                Console.WriteLine("[SETUP] TaskName=" + TaskName);
                Console.WriteLine("[SETUP] Trigger=" + XmlTime(triggerTime));
                SetupEnd();

                TargetBegin();
                registered = root.RegisterTaskDefinition(TaskName, definition, TASK_CREATE, null, null, TASK_LOGON_INTERACTIVE_TOKEN, null);
                if (registered == null) throw new InvalidOperationException("Task creation returned null.");
                Console.WriteLine("[TARGET] TaskName=" + TaskName);
                Console.WriteLine("[TARGET] Operation=Create");
                Console.WriteLine("[TARGET] Trigger=" + XmlTime(triggerTime));
                TargetEnd();
            }
            finally
            {
                try { if (root != null) DeleteTaskIfPresent(root); } catch { }
                ReleaseComObject(registered); ReleaseComObject(action); ReleaseComObject(trigger);
                ReleaseComObject(definition); ReleaseComObject(root); ReleaseComObject(service);
            }
        }

        private static void RunModify()
        {
            dynamic service = null, root = null, baseDef = null, baseTrigger = null, baseAction = null;
            dynamic task = null, definition = null, triggers = null, trigger = null, updated = null;
            try
            {
                SetupBegin();
                OpenScheduler(out service, out root);
                DeleteTaskIfPresent(root);
                DateTime baselineTime = DateTime.Now.AddHours(24);
                baseDef = BuildDefinition(service, "EDR Scheduled Task Baseline", baselineTime, out baseTrigger, out baseAction);
                dynamic created = root.RegisterTaskDefinition(TaskName, baseDef, TASK_CREATE, null, null, TASK_LOGON_INTERACTIVE_TOKEN, null);
                ReleaseComObject(created);
                task = root.GetTask(TaskName);
                definition = task.Definition;
                triggers = definition.Triggers;
                if ((int)triggers.Count != 1) throw new InvalidOperationException("Unexpected trigger count.");
                trigger = triggers.Item(1);
                Console.WriteLine("[SETUP] TaskName=" + TaskName);
                Console.WriteLine("[SETUP] BaselineTrigger=" + XmlTime(baselineTime));
                SetupEnd();

                DateTime modifiedTime = DateTime.Now.AddHours(48);
                TargetBegin();
                trigger.StartBoundary = XmlTime(modifiedTime);
                trigger.EndBoundary = XmlTime(modifiedTime.AddHours(1));
                definition.RegistrationInfo.Description = "EDR Scheduled Task Modification Test";
                updated = root.RegisterTaskDefinition(TaskName, definition, TASK_UPDATE, null, null, TASK_LOGON_INTERACTIVE_TOKEN, null);
                if (updated == null) throw new InvalidOperationException("Task update returned null.");
                Console.WriteLine("[TARGET] TaskName=" + TaskName);
                Console.WriteLine("[TARGET] Operation=Modify");
                Console.WriteLine("[TARGET] NewTrigger=" + XmlTime(modifiedTime));
                TargetEnd();
            }
            finally
            {
                try { if (root != null) DeleteTaskIfPresent(root); } catch { }
                ReleaseComObject(updated); ReleaseComObject(trigger); ReleaseComObject(triggers);
                ReleaseComObject(definition); ReleaseComObject(task); ReleaseComObject(baseAction);
                ReleaseComObject(baseTrigger); ReleaseComObject(baseDef); ReleaseComObject(root); ReleaseComObject(service);
            }
        }

        private static void RunDelete()
        {
            dynamic service = null, root = null, definition = null, trigger = null, action = null, created = null;
            try
            {
                SetupBegin();
                OpenScheduler(out service, out root);
                DeleteTaskIfPresent(root);
                DateTime baselineTime = DateTime.Now.AddHours(24);
                definition = BuildDefinition(service, "EDR Scheduled Task Delete Baseline", baselineTime, out trigger, out action);
                created = root.RegisterTaskDefinition(TaskName, definition, TASK_CREATE, null, null, TASK_LOGON_INTERACTIVE_TOKEN, null);
                if (created == null) throw new InvalidOperationException("Baseline task creation returned null.");
                Console.WriteLine("[SETUP] TaskName=" + TaskName);
                Console.WriteLine("[SETUP] BaselineState=Present");
                SetupEnd();

                TargetBegin();
                root.DeleteTask(TaskName, 0);
                dynamic verify = TryGetTask(root);
                if (verify != null)
                {
                    ReleaseComObject(verify);
                    throw new InvalidOperationException("Task still exists after DeleteTask.");
                }
                Console.WriteLine("[TARGET] TaskName=" + TaskName);
                Console.WriteLine("[TARGET] Operation=Delete");
                Console.WriteLine("[TARGET] FinalState=Absent");
                TargetEnd();
            }
            finally
            {
                ReleaseComObject(created); ReleaseComObject(action); ReleaseComObject(trigger);
                ReleaseComObject(definition); ReleaseComObject(root); ReleaseComObject(service);
            }
        }

        private static void OpenScheduler(out dynamic service, out dynamic root)
        {
            Type serviceType = Type.GetTypeFromProgID("Schedule.Service");
            if (serviceType == null) throw new InvalidOperationException("Schedule.Service COM object unavailable.");
            service = Activator.CreateInstance(serviceType);
            service.Connect();
            root = service.GetFolder("\\");
        }

        private static dynamic BuildDefinition(dynamic service, string description, DateTime start, out dynamic trigger, out dynamic action)
        {
            dynamic definition = service.NewTask(0);
            definition.RegistrationInfo.Description = description;
            definition.RegistrationInfo.Author = Environment.UserName;
            definition.Principal.LogonType = TASK_LOGON_INTERACTIVE_TOKEN;
            definition.Settings.Enabled = true;
            definition.Settings.Hidden = false;
            definition.Settings.StartWhenAvailable = false;
            definition.Settings.ExecutionTimeLimit = "PT1M";

            trigger = definition.Triggers.Create(TASK_TRIGGER_TIME);
            trigger.Id = "EDRTimeTrigger";
            trigger.StartBoundary = XmlTime(start);
            trigger.EndBoundary = XmlTime(start.AddHours(1));
            trigger.Enabled = true;

            string cmdPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "cmd.exe");
            action = definition.Actions.Create(TASK_ACTION_EXEC);
            action.Path = cmdPath;
            action.Arguments = "/c exit 0";
            return definition;
        }

        private static void DeleteTaskIfPresent(dynamic root)
        {
            dynamic existing = TryGetTask(root);
            if (existing == null) return;
            ReleaseComObject(existing);
            root.DeleteTask(TaskName, 0);
        }

        private static dynamic TryGetTask(dynamic rootFolder)
        {
            try { return rootFolder.GetTask(TaskName); }
            catch (COMException ex)
            {
                if ((uint)ex.HResult == 0x80070002u) return null;
                throw;
            }
        }

        private static bool TryGetCase(string[] args, out string caseId)
        {
            caseId = null;
            for (int i = 0; i < args.Length; i++)
            {
                if (string.Equals(args[i], "--case", StringComparison.OrdinalIgnoreCase) && i + 1 < args.Length)
                {
                    caseId = args[i + 1].Trim().ToUpperInvariant();
                    return caseId.Length > 0;
                }
            }
            return false;
        }

        private static string GetAction(string caseId)
        {
            switch (caseId)
            {
                case "TASK-CREATE-001": return "Create";
                case "TASK-MODIFY-001": return "Modify";
                case "TASK-DELETE-001": return "Delete";
                default: return null;
            }
        }

        private static string XmlTime(DateTime value) { return value.ToString("yyyy-MM-dd'T'HH:mm:ss"); }
        private static string UtcNow() { return DateTime.UtcNow.ToString("yyyy-MM-dd'T'HH:mm:ss.fff'Z'"); }
        private static string Sanitize(string value) { return (value ?? "").Replace("\r", " ").Replace("\n", " "); }
        private static string FormatException(Exception ex)
        {
            COMException com = ex as COMException;
            if (com != null) return "COM HRESULT 0x" + ((uint)com.HResult).ToString("X8") + ": " + com.Message;
            return ex.GetType().Name + ": " + ex.Message;
        }
        private static void RunBegin(string runId) { Console.WriteLine("[RUN-BEGIN] RunID=" + runId + " TimeUTC=" + UtcNow()); }
        private static void RunEnd(string runId) { Console.WriteLine("[RUN-END] RunID=" + runId + " TimeUTC=" + UtcNow()); }
        private static void SetupBegin() { Console.WriteLine("[SETUP-BEGIN] TimeUTC=" + UtcNow()); }
        private static void SetupEnd() { Console.WriteLine("[SETUP-END] TimeUTC=" + UtcNow()); }
        private static void TargetBegin() { Console.WriteLine("[TARGET-BEGIN] TimeUTC=" + UtcNow()); }
        private static void TargetEnd() { Console.WriteLine("[TARGET-END] TimeUTC=" + UtcNow()); }

        private static void ReleaseComObject(object value)
        {
            if (value == null) return;
            try { if (Marshal.IsComObject(value)) Marshal.FinalReleaseComObject(value); } catch { }
        }
    }
}
